<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }


    private function _validate($request, $id = null)
    {
        $this->validate($request, [
            'first_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'address' => ['required', 'string', 'max:255'],
            'city' => ['required', 'string'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            // 'end_date' => 'required|max:255',
        ]);
    }
    
    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(Request $request)
    {
        $data = $request->all();
        $this->_validate($request);
        $user = new User($data);
        $user->password=bcrypt(request()->password);
        $user->token=str_random(60);;

        if ($image = $request->file('image')) {
            $root = public_path('destination/');
            $name = $request->file('image')->getClientOriginalName() .'.jpg';            
            \Storage::disk('local')->put("public/".$name ,$request->file('image'));

             $user['image'] = $name;
        }

        $user->save();
        $user = User::Where('id', $user->id)->first();
        return response()->json($user);
    }
}
