<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;

class LoginController extends Controller
{
    public function login(Request $request) {
        $data = $request->all();
        if (Auth::attempt(['email' => $data['email'], 'password' => $data['password']])) {
            $user = User::query()->findOrFail(Auth::user()->id);
            return response()->json($user);
        }
         return response()->json(["message" => "email or password not found"], 404);
    }
}
