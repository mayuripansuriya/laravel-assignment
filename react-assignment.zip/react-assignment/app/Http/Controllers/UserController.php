<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;

class UserController extends Controller
{
    public function getUser($id) {
        $user = User::where('id', $id)->firstOrFail();

return \Storage::disk('local')->get('public/', $user->image);

        if($user) {
        	return response()->json($user);
        } else {
        	return response()->json(["message" => "error"]);
        }
    }

    public function edit(Request $request, $id) {
        $user = User::where('id', $id)->firstOrFail();
        $data = $request->all();
        if($data['image'] == "") {
        	$data['image'] = $user['image'];
        }
        $user->update($data);

        if ($image = $request->file('image')) {
        	 $root = storage_path('public/');
            $name = str_random(20) .$request->file('image')->getClientOriginalName(); 
            $path = $request->file('image')->getRealPath();

            \Storage::disk('local')->put("public/".$name ,$path);
			$user['image'] = $name;
        }
        $user->save();
       
        return response()->json($user);
    }
}
